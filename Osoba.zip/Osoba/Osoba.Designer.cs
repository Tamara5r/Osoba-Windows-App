﻿
namespace Osoba
{
    partial class Osoba
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.text_id = new System.Windows.Forms.TextBox();
            this.text_ime = new System.Windows.Forms.TextBox();
            this.text_prezime = new System.Windows.Forms.TextBox();
            this.text_adresa = new System.Windows.Forms.TextBox();
            this.text_jmbg = new System.Windows.Forms.TextBox();
            this.text_email = new System.Windows.Forms.TextBox();
            this.text_pass = new System.Windows.Forms.TextBox();
            this.text_uloga = new System.Windows.Forms.TextBox();
            this.lbl_id = new System.Windows.Forms.Label();
            this.lbl_ime = new System.Windows.Forms.Label();
            this.lbl_prezime = new System.Windows.Forms.Label();
            this.lbl_adresa = new System.Windows.Forms.Label();
            this.lbl_jmbg = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_pass = new System.Windows.Forms.Label();
            this.lbl_uloga = new System.Windows.Forms.Label();
            this.button_prvi = new System.Windows.Forms.Button();
            this.button_prosli = new System.Windows.Forms.Button();
            this.button_dodaj = new System.Windows.Forms.Button();
            this.button_izmeni = new System.Windows.Forms.Button();
            this.button_brisi = new System.Windows.Forms.Button();
            this.button_sledeci = new System.Windows.Forms.Button();
            this.button_poslednji = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // text_id
            // 
            this.text_id.Enabled = false;
            this.text_id.Location = new System.Drawing.Point(160, 40);
            this.text_id.Name = "text_id";
            this.text_id.Size = new System.Drawing.Size(207, 22);
            this.text_id.TabIndex = 0;
            // 
            // text_ime
            // 
            this.text_ime.Location = new System.Drawing.Point(160, 68);
            this.text_ime.Name = "text_ime";
            this.text_ime.Size = new System.Drawing.Size(207, 22);
            this.text_ime.TabIndex = 1;
            // 
            // text_prezime
            // 
            this.text_prezime.Location = new System.Drawing.Point(160, 96);
            this.text_prezime.Name = "text_prezime";
            this.text_prezime.Size = new System.Drawing.Size(207, 22);
            this.text_prezime.TabIndex = 2;
            // 
            // text_adresa
            // 
            this.text_adresa.Location = new System.Drawing.Point(160, 124);
            this.text_adresa.Name = "text_adresa";
            this.text_adresa.Size = new System.Drawing.Size(207, 22);
            this.text_adresa.TabIndex = 3;
            // 
            // text_jmbg
            // 
            this.text_jmbg.Location = new System.Drawing.Point(160, 152);
            this.text_jmbg.Name = "text_jmbg";
            this.text_jmbg.Size = new System.Drawing.Size(207, 22);
            this.text_jmbg.TabIndex = 4;
            // 
            // text_email
            // 
            this.text_email.Location = new System.Drawing.Point(160, 180);
            this.text_email.Name = "text_email";
            this.text_email.Size = new System.Drawing.Size(207, 22);
            this.text_email.TabIndex = 5;
            // 
            // text_pass
            // 
            this.text_pass.Location = new System.Drawing.Point(160, 208);
            this.text_pass.Name = "text_pass";
            this.text_pass.Size = new System.Drawing.Size(207, 22);
            this.text_pass.TabIndex = 6;
            // 
            // text_uloga
            // 
            this.text_uloga.Location = new System.Drawing.Point(160, 236);
            this.text_uloga.Name = "text_uloga";
            this.text_uloga.Size = new System.Drawing.Size(207, 22);
            this.text_uloga.TabIndex = 7;
            // 
            // lbl_id
            // 
            this.lbl_id.AutoSize = true;
            this.lbl_id.Location = new System.Drawing.Point(34, 40);
            this.lbl_id.Name = "lbl_id";
            this.lbl_id.Size = new System.Drawing.Size(21, 17);
            this.lbl_id.TabIndex = 8;
            this.lbl_id.Text = "ID";
            // 
            // lbl_ime
            // 
            this.lbl_ime.AutoSize = true;
            this.lbl_ime.Location = new System.Drawing.Point(34, 68);
            this.lbl_ime.Name = "lbl_ime";
            this.lbl_ime.Size = new System.Drawing.Size(30, 17);
            this.lbl_ime.TabIndex = 9;
            this.lbl_ime.Text = "Ime";
            // 
            // lbl_prezime
            // 
            this.lbl_prezime.AutoSize = true;
            this.lbl_prezime.Location = new System.Drawing.Point(34, 96);
            this.lbl_prezime.Name = "lbl_prezime";
            this.lbl_prezime.Size = new System.Drawing.Size(59, 17);
            this.lbl_prezime.TabIndex = 10;
            this.lbl_prezime.Text = "Prezime";
            // 
            // lbl_adresa
            // 
            this.lbl_adresa.AutoSize = true;
            this.lbl_adresa.Location = new System.Drawing.Point(34, 124);
            this.lbl_adresa.Name = "lbl_adresa";
            this.lbl_adresa.Size = new System.Drawing.Size(53, 17);
            this.lbl_adresa.TabIndex = 11;
            this.lbl_adresa.Text = "Adresa";
            // 
            // lbl_jmbg
            // 
            this.lbl_jmbg.AutoSize = true;
            this.lbl_jmbg.Location = new System.Drawing.Point(34, 152);
            this.lbl_jmbg.Name = "lbl_jmbg";
            this.lbl_jmbg.Size = new System.Drawing.Size(46, 17);
            this.lbl_jmbg.TabIndex = 12;
            this.lbl_jmbg.Text = "JMBG";
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Location = new System.Drawing.Point(34, 180);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(42, 17);
            this.lbl_email.TabIndex = 13;
            this.lbl_email.Text = "Email";
            // 
            // lbl_pass
            // 
            this.lbl_pass.AutoSize = true;
            this.lbl_pass.Location = new System.Drawing.Point(34, 208);
            this.lbl_pass.Name = "lbl_pass";
            this.lbl_pass.Size = new System.Drawing.Size(69, 17);
            this.lbl_pass.TabIndex = 14;
            this.lbl_pass.Text = "Password";
            // 
            // lbl_uloga
            // 
            this.lbl_uloga.AutoSize = true;
            this.lbl_uloga.Location = new System.Drawing.Point(34, 236);
            this.lbl_uloga.Name = "lbl_uloga";
            this.lbl_uloga.Size = new System.Drawing.Size(45, 17);
            this.lbl_uloga.TabIndex = 15;
            this.lbl_uloga.Text = "Uloga";
            // 
            // button_prvi
            // 
            this.button_prvi.Location = new System.Drawing.Point(37, 297);
            this.button_prvi.Name = "button_prvi";
            this.button_prvi.Size = new System.Drawing.Size(75, 23);
            this.button_prvi.TabIndex = 16;
            this.button_prvi.Text = "<<";
            this.button_prvi.UseVisualStyleBackColor = true;
            this.button_prvi.Click += new System.EventHandler(this.button_prvi_Click);
            // 
            // button_prosli
            // 
            this.button_prosli.Location = new System.Drawing.Point(118, 297);
            this.button_prosli.Name = "button_prosli";
            this.button_prosli.Size = new System.Drawing.Size(75, 23);
            this.button_prosli.TabIndex = 17;
            this.button_prosli.Text = "<";
            this.button_prosli.UseVisualStyleBackColor = true;
            this.button_prosli.Click += new System.EventHandler(this.button_prosli_Click);
            // 
            // button_dodaj
            // 
            this.button_dodaj.Location = new System.Drawing.Point(199, 297);
            this.button_dodaj.Name = "button_dodaj";
            this.button_dodaj.Size = new System.Drawing.Size(75, 23);
            this.button_dodaj.TabIndex = 18;
            this.button_dodaj.Text = "Dodaj";
            this.button_dodaj.UseVisualStyleBackColor = true;
            this.button_dodaj.Click += new System.EventHandler(this.button_dodaj_Click);
            // 
            // button_izmeni
            // 
            this.button_izmeni.Location = new System.Drawing.Point(280, 297);
            this.button_izmeni.Name = "button_izmeni";
            this.button_izmeni.Size = new System.Drawing.Size(75, 23);
            this.button_izmeni.TabIndex = 19;
            this.button_izmeni.Text = "Izmeni";
            this.button_izmeni.UseVisualStyleBackColor = true;
            this.button_izmeni.Click += new System.EventHandler(this.button_izmeni_Click);
            // 
            // button_brisi
            // 
            this.button_brisi.Location = new System.Drawing.Point(361, 297);
            this.button_brisi.Name = "button_brisi";
            this.button_brisi.Size = new System.Drawing.Size(75, 23);
            this.button_brisi.TabIndex = 20;
            this.button_brisi.Text = "Brisi";
            this.button_brisi.UseVisualStyleBackColor = true;
            this.button_brisi.Click += new System.EventHandler(this.button_brisi_Click);
            // 
            // button_sledeci
            // 
            this.button_sledeci.Location = new System.Drawing.Point(442, 297);
            this.button_sledeci.Name = "button_sledeci";
            this.button_sledeci.Size = new System.Drawing.Size(75, 23);
            this.button_sledeci.TabIndex = 21;
            this.button_sledeci.Text = ">";
            this.button_sledeci.UseVisualStyleBackColor = true;
            this.button_sledeci.Click += new System.EventHandler(this.button_sledeci_Click);
            // 
            // button_poslednji
            // 
            this.button_poslednji.Location = new System.Drawing.Point(523, 297);
            this.button_poslednji.Name = "button_poslednji";
            this.button_poslednji.Size = new System.Drawing.Size(75, 23);
            this.button_poslednji.TabIndex = 22;
            this.button_poslednji.Text = ">>";
            this.button_poslednji.UseVisualStyleBackColor = true;
            this.button_poslednji.Click += new System.EventHandler(this.button_poslednji_Click);
            // 
            // Osoba
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_poslednji);
            this.Controls.Add(this.button_sledeci);
            this.Controls.Add(this.button_brisi);
            this.Controls.Add(this.button_izmeni);
            this.Controls.Add(this.button_dodaj);
            this.Controls.Add(this.button_prosli);
            this.Controls.Add(this.button_prvi);
            this.Controls.Add(this.lbl_uloga);
            this.Controls.Add(this.lbl_pass);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_jmbg);
            this.Controls.Add(this.lbl_adresa);
            this.Controls.Add(this.lbl_prezime);
            this.Controls.Add(this.lbl_ime);
            this.Controls.Add(this.lbl_id);
            this.Controls.Add(this.text_uloga);
            this.Controls.Add(this.text_pass);
            this.Controls.Add(this.text_email);
            this.Controls.Add(this.text_jmbg);
            this.Controls.Add(this.text_adresa);
            this.Controls.Add(this.text_prezime);
            this.Controls.Add(this.text_ime);
            this.Controls.Add(this.text_id);
            this.Name = "Osoba";
            this.Text = "Osoba";
            this.Load += new System.EventHandler(this.Osoba_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox text_id;
        private System.Windows.Forms.TextBox text_ime;
        private System.Windows.Forms.TextBox text_prezime;
        private System.Windows.Forms.TextBox text_adresa;
        private System.Windows.Forms.TextBox text_jmbg;
        private System.Windows.Forms.TextBox text_email;
        private System.Windows.Forms.TextBox text_pass;
        private System.Windows.Forms.TextBox text_uloga;
        private System.Windows.Forms.Label lbl_id;
        private System.Windows.Forms.Label lbl_ime;
        private System.Windows.Forms.Label lbl_prezime;
        private System.Windows.Forms.Label lbl_adresa;
        private System.Windows.Forms.Label lbl_jmbg;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_pass;
        private System.Windows.Forms.Label lbl_uloga;
        private System.Windows.Forms.Button button_prvi;
        private System.Windows.Forms.Button button_prosli;
        private System.Windows.Forms.Button button_dodaj;
        private System.Windows.Forms.Button button_izmeni;
        private System.Windows.Forms.Button button_brisi;
        private System.Windows.Forms.Button button_sledeci;
        private System.Windows.Forms.Button button_poslednji;
    }
}